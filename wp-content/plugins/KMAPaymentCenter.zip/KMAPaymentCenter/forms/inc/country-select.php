<option value="">Please Select</option>
<option value="US" <?php echo $billingCountry == "US" || $billingCountry == '' ? "selected" : "" ?>>United States</option>
<option value="CA" <?php echo $billingCountry == "CA" ? "selected" : "" ?>>Canada</option>
<option value="UK" <?php echo $billingCountry == "UK" ? "selected" : "" ?>>United Kingdom</option>
<option value="AU" <?php echo $billingCountry == "AU" ? "selected" : "" ?>>Australia</option>
<option value="AF" <?php echo $billingCountry == "AF" ? "selected" : "" ?>>Afghanistan</option>
<option value="AL" <?php echo $billingCountry == "AL" ? "selected" : "" ?>>Albania</option>
<option value="DZ" <?php echo $billingCountry == "DZ" ? "selected" : "" ?>>Algeria</option>
<option value="AS" <?php echo $billingCountry == "AS" ? "selected" : "" ?>>American Samoa</option>
<option value="AD" <?php echo $billingCountry == "AD" ? "selected" : "" ?>>Andorra</option>
<option value="AO" <?php echo $billingCountry == "AO" ? "selected" : "" ?>>Angola</option>
<option value="AI" <?php echo $billingCountry == "AI" ? "selected" : "" ?>>Anguilla</option>
<option value="AQ" <?php echo $billingCountry == "AQ" ? "selected" : "" ?>>Antarctica</option>
<option value="AG" <?php echo $billingCountry == "AG" ? "selected" : "" ?>>Antigua and Barbuda</option>
<option value="AR" <?php echo $billingCountry == "AR" ? "selected" : "" ?>>Argentina</option>
<option value="AM" <?php echo $billingCountry == "AM" ? "selected" : "" ?>>Armenia</option>
<option value="AW" <?php echo $billingCountry == "AW" ? "selected" : "" ?>>Aruba</option>
<option value="AT" <?php echo $billingCountry == "AT" ? "selected" : "" ?>>Austria</option>
<option value="AZ" <?php echo $billingCountry == "AZ" ? "selected" : "" ?>>Azerbaijan</option>
<option value="BS" <?php echo $billingCountry == "BS" ? "selected" : "" ?>>Bahamas</option>
<option value="BH" <?php echo $billingCountry == "BH" ? "selected" : "" ?>>Bahrain</option>
<option value="BD" <?php echo $billingCountry == "BD" ? "selected" : "" ?>>Bangladesh</option>
<option value="BB" <?php echo $billingCountry == "BB" ? "selected" : "" ?>>Barbados</option>
<option value="BY" <?php echo $billingCountry == "BY" ? "selected" : "" ?>>Belarus</option>
<option value="BE" <?php echo $billingCountry == "BE" ? "selected" : "" ?>>Belgium</option>
<option value="BZ" <?php echo $billingCountry == "BZ" ? "selected" : "" ?>>Belize</option>
<option value="BJ" <?php echo $billingCountry == "BJ" ? "selected" : "" ?>>Benin</option>
<option value="BM" <?php echo $billingCountry == "BM" ? "selected" : "" ?>>Bermuda</option>
<option value="BT" <?php echo $billingCountry == "BT" ? "selected" : "" ?>>Bhutan</option>
<option value="BO" <?php echo $billingCountry == "BO" ? "selected" : "" ?>>Bolivia</option>
<option value="BA" <?php echo $billingCountry == "BA" ? "selected" : "" ?>>Bosnia and Herzegovina</option>
<option value="BW" <?php echo $billingCountry == "BW" ? "selected" : "" ?>>Botswana</option>
<option value="BR" <?php echo $billingCountry == "BR" ? "selected" : "" ?>>Brazil</option>
<option value="BN" <?php echo $billingCountry == "BN" ? "selected" : "" ?>>Brunei Darussalam</option>
<option value="BG" <?php echo $billingCountry == "BG" ? "selected" : "" ?>>Bulgaria</option>
<option value="BF" <?php echo $billingCountry == "BF" ? "selected" : "" ?>>Burkina Faso</option>
<option value="BI" <?php echo $billingCountry == "BI" ? "selected" : "" ?>>Burundi</option>
<option value="KH" <?php echo $billingCountry == "KH" ? "selected" : "" ?>>Cambodia</option>
<option value="CM" <?php echo $billingCountry == "CM" ? "selected" : "" ?>>Cameroon</option>
<option value="CV" <?php echo $billingCountry == "CV" ? "selected" : "" ?>>Cape Verde</option>
<option value="KY" <?php echo $billingCountry == "KY" ? "selected" : "" ?>>Cayman Islands</option>
<option value="CF" <?php echo $billingCountry == "CF" ? "selected" : "" ?>>Central African Republic</option>
<option value="TD" <?php echo $billingCountry == "TD" ? "selected" : "" ?>>Chad</option>
<option value="CL" <?php echo $billingCountry == "CL" ? "selected" : "" ?>>Chile</option>
<option value="CN" <?php echo $billingCountry == "CN" ? "selected" : "" ?>>China</option>
<option value="CX" <?php echo $billingCountry == "CX" ? "selected" : "" ?>>Christmas Island</option>
<option value="CC" <?php echo $billingCountry == "CC" ? "selected" : "" ?>>Cocos (Keeling) Islands</option>
<option value="CO" <?php echo $billingCountry == "CO" ? "selected" : "" ?>>Colombia</option>
<option value="KM" <?php echo $billingCountry == "KM" ? "selected" : "" ?>>Comoros</option>
<option value="CG" <?php echo $billingCountry == "CG" ? "selected" : "" ?>>Congo</option>
<option value="CD" <?php echo $billingCountry == "CD" ? "selected" : "" ?>>Congo, The Democratic Republic of the
</option>
<option value="CK" <?php echo $billingCountry == "CK" ? "selected" : "" ?>>Cook Islands</option>
<option value="CR" <?php echo $billingCountry == "CR" ? "selected" : "" ?>>Costa Rica</option>
<option value="CI" <?php echo $billingCountry == "CI" ? "selected" : "" ?>>Cote D`Ivoire</option>
<option value="HR" <?php echo $billingCountry == "HR" ? "selected" : "" ?>>Croatia</option>
<option value="CY" <?php echo $billingCountry == "CY" ? "selected" : "" ?>>Cyprus</option>
<option value="CZ" <?php echo $billingCountry == "CZ" ? "selected" : "" ?>>Czech Republic</option>
<option value="DK" <?php echo $billingCountry == "DK" ? "selected" : "" ?>>Denmark</option>
<option value="DJ" <?php echo $billingCountry == "DJ" ? "selected" : "" ?>>Djibouti</option>
<option value="DM" <?php echo $billingCountry == "DM" ? "selected" : "" ?>>Dominica</option>
<option value="DO" <?php echo $billingCountry == "DO" ? "selected" : "" ?>>Dominican Republic</option>
<option value="EC" <?php echo $billingCountry == "EC" ? "selected" : "" ?>>Ecuador</option>
<option value="EG" <?php echo $billingCountry == "EG" ? "selected" : "" ?>>Egypt</option>
<option value="SV" <?php echo $billingCountry == "SV" ? "selected" : "" ?>>El Salvador</option>
<option value="GQ" <?php echo $billingCountry == "GQ" ? "selected" : "" ?>>Equatorial Guinea</option>
<option value="ER" <?php echo $billingCountry == "ER" ? "selected" : "" ?>>Eritrea</option>
<option value="EE" <?php echo $billingCountry == "EE" ? "selected" : "" ?>>Estonia</option>
<option value="ET" <?php echo $billingCountry == "ET" ? "selected" : "" ?>>Ethiopia</option>
<option value="FK" <?php echo $billingCountry == "FK" ? "selected" : "" ?>>Falkland Islands (Malvinas)</option>
<option value="FO" <?php echo $billingCountry == "FO" ? "selected" : "" ?>>Faroe Islands</option>
<option value="FJ" <?php echo $billingCountry == "FJ" ? "selected" : "" ?>>Fiji</option>
<option value="FI" <?php echo $billingCountry == "FI" ? "selected" : "" ?>>Finland</option>
<option value="FR" <?php echo $billingCountry == "FR" ? "selected" : "" ?>>France</option>
<option value="GF" <?php echo $billingCountry == "GF" ? "selected" : "" ?>>French Guiana</option>
<option value="PF" <?php echo $billingCountry == "PF" ? "selected" : "" ?>>French Polynesia</option>
<option value="GA" <?php echo $billingCountry == "GA" ? "selected" : "" ?>>Gabon</option>
<option value="GM" <?php echo $billingCountry == "GM" ? "selected" : "" ?>>Gambia</option>
<option value="GE" <?php echo $billingCountry == "GE" ? "selected" : "" ?>>Georgia</option>
<option value="DE" <?php echo $billingCountry == "DE" ? "selected" : "" ?>>Germany</option>
<option value="GH" <?php echo $billingCountry == "GH" ? "selected" : "" ?>>Ghana</option>
<option value="GI" <?php echo $billingCountry == "GI" ? "selected" : "" ?>>Gibraltar</option>
<option value="GR" <?php echo $billingCountry == "GR" ? "selected" : "" ?>>Greece</option>
<option value="GL" <?php echo $billingCountry == "GL" ? "selected" : "" ?>>Greenland</option>
<option value="GD" <?php echo $billingCountry == "GD" ? "selected" : "" ?>>Grenada</option>
<option value="GP" <?php echo $billingCountry == "GP" ? "selected" : "" ?>>Guadeloupe</option>
<option value="GU" <?php echo $billingCountry == "GU" ? "selected" : "" ?>>Guam</option>
<option value="GT" <?php echo $billingCountry == "GT" ? "selected" : "" ?>>Guatemala</option>
<option value="GN" <?php echo $billingCountry == "GN" ? "selected" : "" ?>>Guinea</option>
<option value="GW" <?php echo $billingCountry == "GW" ? "selected" : "" ?>>Guinea-Bissau</option>
<option value="GY" <?php echo $billingCountry == "GY" ? "selected" : "" ?>>Guyana</option>
<option value="HT" <?php echo $billingCountry == "HT" ? "selected" : "" ?>>Haiti</option>
<option value="HN" <?php echo $billingCountry == "HN" ? "selected" : "" ?>>Honduras</option>
<option value="HK" <?php echo $billingCountry == "HK" ? "selected" : "" ?>>Hong Kong</option>
<option value="HU" <?php echo $billingCountry == "HU" ? "selected" : "" ?>>Hungary</option>
<option value="IS" <?php echo $billingCountry == "IS" ? "selected" : "" ?>>Iceland</option>
<option value="IN" <?php echo $billingCountry == "IN" ? "selected" : "" ?>>India</option>
<option value="ID" <?php echo $billingCountry == "ID" ? "selected" : "" ?>>Indonesia</option>
<option value="IR" <?php echo $billingCountry == "IR" ? "selected" : "" ?>>Iran (Islamic Republic Of)</option>
<option value="IQ" <?php echo $billingCountry == "IQ" ? "selected" : "" ?>>Iraq</option>
<option value="IE" <?php echo $billingCountry == "IE" ? "selected" : "" ?>>Ireland</option>
<option value="IL" <?php echo $billingCountry == "IL" ? "selected" : "" ?>>Israel</option>
<option value="IT" <?php echo $billingCountry == "IT" ? "selected" : "" ?>>Italy</option>
<option value="JM" <?php echo $billingCountry == "JM" ? "selected" : "" ?>>Jamaica</option>
<option value="JP" <?php echo $billingCountry == "JP" ? "selected" : "" ?>>Japan</option>
<option value="JO" <?php echo $billingCountry == "JO" ? "selected" : "" ?>>Jordan</option>
<option value="KZ" <?php echo $billingCountry == "KZ" ? "selected" : "" ?>>Kazakhstan</option>
<option value="KE" <?php echo $billingCountry == "KE" ? "selected" : "" ?>>Kenya</option>
<option value="KI" <?php echo $billingCountry == "KI" ? "selected" : "" ?>>Kiribati</option>
<option value="KP" <?php echo $billingCountry == "KP" ? "selected" : "" ?>>Korea North</option>
<option value="KR" <?php echo $billingCountry == "KR" ? "selected" : "" ?>>Korea South</option>
<option value="KW" <?php echo $billingCountry == "KW" ? "selected" : "" ?>>Kuwait</option>
<option value="KG" <?php echo $billingCountry == "KG" ? "selected" : "" ?>>Kyrgyzstan</option>
<option value="LA" <?php echo $billingCountry == "LA" ? "selected" : "" ?>>Laos</option>
<option value="LV" <?php echo $billingCountry == "LV" ? "selected" : "" ?>>Latvia</option>
<option value="LB" <?php echo $billingCountry == "LB" ? "selected" : "" ?>>Lebanon</option>
<option value="LS" <?php echo $billingCountry == "LS" ? "selected" : "" ?>>Lesotho</option>
<option value="LR" <?php echo $billingCountry == "LR" ? "selected" : "" ?>>Liberia</option>
<option value="LI" <?php echo $billingCountry == "LI" ? "selected" : "" ?>>Liechtenstein</option>
<option value="LT" <?php echo $billingCountry == "LT" ? "selected" : "" ?>>Lithuania</option>
<option value="LU" <?php echo $billingCountry == "LU" ? "selected" : "" ?>>Luxembourg</option>
<option value="MO" <?php echo $billingCountry == "MO" ? "selected" : "" ?>>Macau</option>
<option value="MK" <?php echo $billingCountry == "MK" ? "selected" : "" ?>>Macedonia</option>
<option value="MG" <?php echo $billingCountry == "MG" ? "selected" : "" ?>>Madagascar</option>
<option value="MW" <?php echo $billingCountry == "MW" ? "selected" : "" ?>>Malawi</option>
<option value="MY" <?php echo $billingCountry == "MY" ? "selected" : "" ?>>Malaysia</option>
<option value="MV" <?php echo $billingCountry == "MV" ? "selected" : "" ?>>Maldives</option>
<option value="ML" <?php echo $billingCountry == "ML" ? "selected" : "" ?>>Mali</option>
<option value="MT" <?php echo $billingCountry == "MT" ? "selected" : "" ?>>Malta</option>
<option value="MH" <?php echo $billingCountry == "MH" ? "selected" : "" ?>>Marshall Islands</option>
<option value="MQ" <?php echo $billingCountry == "MQ" ? "selected" : "" ?>>Martinique</option>
<option value="MR" <?php echo $billingCountry == "MR" ? "selected" : "" ?>>Mauritania</option>
<option value="MU" <?php echo $billingCountry == "MU" ? "selected" : "" ?>>Mauritius</option>
<option value="MX" <?php echo $billingCountry == "MX" ? "selected" : "" ?>>Mexico</option>
<option value="FM" <?php echo $billingCountry == "FM" ? "selected" : "" ?>>Micronesia</option>
<option value="MD" <?php echo $billingCountry == "MD" ? "selected" : "" ?>>Moldova</option>
<option value="MC" <?php echo $billingCountry == "MC" ? "selected" : "" ?>>Monaco</option>
<option value="MN" <?php echo $billingCountry == "MN" ? "selected" : "" ?>>Mongolia</option>
<option value="MS" <?php echo $billingCountry == "MS" ? "selected" : "" ?>>Montserrat</option>
<option value="MA" <?php echo $billingCountry == "MA" ? "selected" : "" ?>>Morocco</option>
<option value="MZ" <?php echo $billingCountry == "MZ" ? "selected" : "" ?>>Mozambique</option>
<option value="NA" <?php echo $billingCountry == "NA" ? "selected" : "" ?>>Namibia</option>
<option value="NP" <?php echo $billingCountry == "NP" ? "selected" : "" ?>>Nepal</option>
<option value="NL" <?php echo $billingCountry == "NL" ? "selected" : "" ?>>Netherlands</option>
<option value="AN" <?php echo $billingCountry == "AN" ? "selected" : "" ?>>Netherlands Antilles</option>
<option value="NC" <?php echo $billingCountry == "NC" ? "selected" : "" ?>>New Caledonia</option>
<option value="NZ" <?php echo $billingCountry == "NZ" ? "selected" : "" ?>>New Zealand</option>
<option value="NI" <?php echo $billingCountry == "NI" ? "selected" : "" ?>>Nicaragua</option>
<option value="NE" <?php echo $billingCountry == "NE" ? "selected" : "" ?>>Niger</option>
<option value="NG" <?php echo $billingCountry == "NG" ? "selected" : "" ?>>Nigeria</option>
<option value="NO" <?php echo $billingCountry == "NO" ? "selected" : "" ?>>Norway</option>
<option value="OM" <?php echo $billingCountry == "OM" ? "selected" : "" ?>>Oman</option>
<option value="PK" <?php echo $billingCountry == "PK" ? "selected" : "" ?>>Pakistan</option>
<option value="PW" <?php echo $billingCountry == "PW" ? "selected" : "" ?>>Palau</option>
<option value="PS" <?php echo $billingCountry == "PS" ? "selected" : "" ?>>Palestine Autonomous</option>
<option value="PA" <?php echo $billingCountry == "PA" ? "selected" : "" ?>>Panama</option>
<option value="PG" <?php echo $billingCountry == "PG" ? "selected" : "" ?>>Papua New Guinea</option>
<option value="PY" <?php echo $billingCountry == "PY" ? "selected" : "" ?>>Paraguay</option>
<option value="PE" <?php echo $billingCountry == "PE" ? "selected" : "" ?>>Peru</option>
<option value="PH" <?php echo $billingCountry == "PH" ? "selected" : "" ?>>Philippines</option>
<option value="PL" <?php echo $billingCountry == "PL" ? "selected" : "" ?>>Poland</option>
<option value="PT" <?php echo $billingCountry == "PT" ? "selected" : "" ?>>Portugal</option>
<option value="PR" <?php echo $billingCountry == "PR" ? "selected" : "" ?>>Puerto Rico</option>
<option value="QA" <?php echo $billingCountry == "QA" ? "selected" : "" ?>>Qatar</option>
<option value="RE" <?php echo $billingCountry == "RE" ? "selected" : "" ?>>Reunion</option>
<option value="RO" <?php echo $billingCountry == "RO" ? "selected" : "" ?>>Romania</option>
<option value="RU" <?php echo $billingCountry == "RU" ? "selected" : "" ?>>Russian Federation</option>
<option value="RW" <?php echo $billingCountry == "RW" ? "selected" : "" ?>>Rwanda</option>
<option value="VC" <?php echo $billingCountry == "VC" ? "selected" : "" ?>>Saint Vincent and the Grenadines
</option>
<option value="MP" <?php echo $billingCountry == "MP" ? "selected" : "" ?>>Saipan</option>
<option value="SM" <?php echo $billingCountry == "SM" ? "selected" : "" ?>>San Marino</option>
<option value="SA" <?php echo $billingCountry == "SA" ? "selected" : "" ?>>Saudi Arabia</option>
<option value="SN" <?php echo $billingCountry == "SN" ? "selected" : "" ?>>Senegal</option>
<option value="SC" <?php echo $billingCountry == "SC" ? "selected" : "" ?>>Seychelles</option>
<option value="SL" <?php echo $billingCountry == "SL" ? "selected" : "" ?>>Sierra Leone</option>
<option value="SG" <?php echo $billingCountry == "SG" ? "selected" : "" ?>>Singapore</option>
<option value="SK" <?php echo $billingCountry == "SK" ? "selected" : "" ?>>Slovak Republic</option>
<option value="SI" <?php echo $billingCountry == "SI" ? "selected" : "" ?>>Slovenia</option>
<option value="SO" <?php echo $billingCountry == "SO" ? "selected" : "" ?>>Somalia</option>
<option value="ZA" <?php echo $billingCountry == "ZA" ? "selected" : "" ?>>South Africa</option>
<option value="ES" <?php echo $billingCountry == "ES" ? "selected" : "" ?>>Spain</option>
<option value="LK" <?php echo $billingCountry == "LK" ? "selected" : "" ?>>Sri Lanka</option>
<option value="KN" <?php echo $billingCountry == "KN" ? "selected" : "" ?>>St. Kitts/Nevis</option>
<option value="LC" <?php echo $billingCountry == "LC" ? "selected" : "" ?>>St. Lucia</option>
<option value="SD" <?php echo $billingCountry == "SD" ? "selected" : "" ?>>Sudan</option>
<option value="SR" <?php echo $billingCountry == "SR" ? "selected" : "" ?>>Suriname</option>
<option value="SZ" <?php echo $billingCountry == "SZ" ? "selected" : "" ?>>Swaziland</option>
<option value="SE" <?php echo $billingCountry == "SE" ? "selected" : "" ?>>Sweden</option>
<option value="CH" <?php echo $billingCountry == "CH" ? "selected" : "" ?>>Switzerland</option>
<option value="SY" <?php echo $billingCountry == "SY" ? "selected" : "" ?>>Syria</option>
<option value="TW" <?php echo $billingCountry == "TW" ? "selected" : "" ?>>Taiwan</option>
<option value="TI" <?php echo $billingCountry == "TI" ? "selected" : "" ?>>Tajikistan</option>
<option value="TZ" <?php echo $billingCountry == "TZ" ? "selected" : "" ?>>Tanzania</option>
<option value="TH" <?php echo $billingCountry == "TH" ? "selected" : "" ?>>Thailand</option>
<option value="TG" <?php echo $billingCountry == "TG" ? "selected" : "" ?>>Togo</option>
<option value="TK" <?php echo $billingCountry == "TK" ? "selected" : "" ?>>Tokelau</option>
<option value="TO" <?php echo $billingCountry == "TO" ? "selected" : "" ?>>Tonga</option>
<option value="TT" <?php echo $billingCountry == "TT" ? "selected" : "" ?>>Trinidad and Tobago</option>
<option value="TN" <?php echo $billingCountry == "TN" ? "selected" : "" ?>>Tunisia</option>
<option value="TR" <?php echo $billingCountry == "TR" ? "selected" : "" ?>>Turkey</option>
<option value="TM" <?php echo $billingCountry == "TM" ? "selected" : "" ?>>Turkmenistan</option>
<option value="TC" <?php echo $billingCountry == "TC" ? "selected" : "" ?>>Turks and Caicos Islands</option>
<option value="TV" <?php echo $billingCountry == "TV" ? "selected" : "" ?>>Tuvalu</option>
<option value="UG" <?php echo $billingCountry == "UG" ? "selected" : "" ?>>Uganda</option>
<option value="UA" <?php echo $billingCountry == "UA" ? "selected" : "" ?>>Ukraine</option>
<option value="AE" <?php echo $billingCountry == "AE" ? "selected" : "" ?>>United Arab Emirates</option>
<option value="UY" <?php echo $billingCountry == "UY" ? "selected" : "" ?>>Uruguay</option>
<option value="UZ" <?php echo $billingCountry == "UZ" ? "selected" : "" ?>>Uzbekistan</option>
<option value="VU" <?php echo $billingCountry == "VU" ? "selected" : "" ?>>Vanuatu</option>
<option value="VE" <?php echo $billingCountry == "VE" ? "selected" : "" ?>>Venezuela</option>
<option value="VN" <?php echo $billingCountry == "VN" ? "selected" : "" ?>>Viet Nam</option>
<option value="VG" <?php echo $billingCountry == "VG" ? "selected" : "" ?>>Virgin Islands (British)</option>
<option value="VI" <?php echo $billingCountry == "VI" ? "selected" : "" ?>>Virgin Islands (U.S.)</option>
<option value="WF" <?php echo $billingCountry == "WF" ? "selected" : "" ?>>Wallis and Futuna Islands</option>
<option value="YE" <?php echo $billingCountry == "YE" ? "selected" : "" ?>>Yemen</option>
<option value="YU" <?php echo $billingCountry == "YU" ? "selected" : "" ?>>Yugoslavia</option>
<option value="ZM" <?php echo $billingCountry == "ZM" ? "selected" : "" ?>>Zambia</option>
<option value="ZW" <?php echo $billingCountry == "ZW" ? "selected" : "" ?>>Zimbabwe</option>