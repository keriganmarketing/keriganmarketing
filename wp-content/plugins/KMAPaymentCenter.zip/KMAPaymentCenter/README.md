`~Current Version:1.8~`

Details
---
Use at your own risk.

Change Log
---
#### 1.8.1:
* More validation
* Bootstrap template
#### 1.8:
* Beta Release
* Pay by invoice number with open amount
* Pay pre-defined service/one-time amount
* Pay pre-defined service/recurring amount
#### 1.7.2:
* Hotfix
#### 1.7.1:
* Hotfix
#### 1.7:
* Added admin pages and configured updater
#### 1.2:
* Added installation scripts
* Added uninstallation scripts
#### 1.0:
* Initial Build